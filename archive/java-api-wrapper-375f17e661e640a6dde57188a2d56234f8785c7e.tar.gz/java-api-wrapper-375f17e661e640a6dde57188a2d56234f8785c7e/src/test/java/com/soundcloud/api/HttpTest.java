package com.soundcloud.api;

import org.junit.Test;

public class HttpTest {
    @Test
    public void test() throws Exception {
        // TODO
    }
}
