package de.voidplus.soundcloud;


import com.google.gson.Gson;
import com.soundcloud.api.*;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class SoundCloud {


    public static final String VERSION = "0.2.1";


    public enum Type {
        USER,
        TRACK,
        PLAYLIST,
        COMMENT,
        GROUP
    }

    public enum Rest {
        GET,
        PUT,
        POST,
        DELETE
    }


    protected final String app_client_id;
    protected final String app_client_secret;

    protected Token token;
    protected ApiWrapper wrapper;

    protected JSONParser parser;
    protected Gson gson;


    /**
     * Constructor of the SoundCloud wrapper, which creates the API wrapper and generates the Access Token.
     *
     * @param _app_client_id     Application Client ID
     * @param _app_client_secret Application Client Secret
     */
    public SoundCloud(String _app_client_id, String _app_client_secret) {
        this.app_client_id = _app_client_id;
        this.app_client_secret = _app_client_secret;

        this.parser = new JSONParser();
        this.gson = new Gson();

        wrapper = new ApiWrapper(app_client_id, app_client_secret, null, null);
        wrapper.setToken(null);
        wrapper.setDefaultContentType("application/json");
    }


    /**
     * Constructor of the SoundCloud wrapper, which creates the API wrapper and generates the Access Token.
     *
     * @param _app_client_id     Application client ID
     * @param _app_client_secret Application client secret
     */
    public SoundCloud(String _app_client_id, String _app_client_secret, String _login_name, String _login_password) {
        this(_app_client_id, _app_client_secret);
        this.login(_login_name, _login_password);
    }


    /**
     * Login to get a valid token.
     *
     * @param _login_name     SoundCloud login name
     * @param _login_password SoundCloud login pass
     * @return Boolean state of login
     */
    public boolean login(String _login_name, String _login_password) {
        try {
            this.token = wrapper.login(_login_name, _login_password, Token.SCOPE_NON_EXPIRING);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * Filter API string.
     *
     * @param api
     * @return
     */
    private String filterApiString(String api) {
        if (api.length() > 0) {
            // Suppressing / Forcing the `/.` at the beginning
            if (!api.startsWith("/")) {
                api = "/" + api;
            }
            // Removing the '/' at the end
            if (api.charAt(api.length() - 1) == '/') {
                api = api.substring(0, api.length() - 1);
            }
            // Define the format to ".json"
            api = api.replace(".format", ".json").replace(".xml", ".json");
            if (api.indexOf(".json") == -1) {
                api += ".json";
            }
            return api;
        }
        // TODO: throw exception if api string is empty
        return null;
    }

    /**
     * Define type of result.
     *
     * @param api
     * @return
     */
    private Type defineApiType(String api) {
        Type type = null;
        if (
                api.matches("^/me.json") ||
                        api.matches("^/me/(followings(/[0-9]+)?|followers(/[0-9]+)?).json") ||
                        api.matches("^/users(/[0-9]+)?.json") ||
                        api.matches("^/users/([0-9]+)/(followings|followers).json") ||
                        api.matches("^/groups/([0-9]+)/(users|moderators|members|contributors).json")
                ) {
            type = Type.USER;
        } else if (
                api.matches("^/tracks(/[0-9]+)?.json") ||
                        api.matches("^/me/(tracks|favorites)(/[0-9]+)?.json") ||
                        api.matches("^/users/([0-9]+)/(tracks|favorites).json")
                ) {
            type = Type.TRACK;
        } else if (
                api.matches("^/playlists(/[0-9]+)?.json") ||
                        api.matches("^/me/playlists.json") ||
                        api.matches("^/users/([0-9]+)/playlists.json") ||
                        api.matches("^/groups/([0-9]+)/tracks.json")
                ) {
            type = Type.PLAYLIST;
        } else if (
                api.matches("^/comments/([0-9]+).json") ||
                        api.matches("^/me/comments.json") ||
                        api.matches("^/tracks/([0-9]+)/comments.json")
                ) {
            type = Type.COMMENT;
        } else if (
                api.matches("^/groups(/[0-9]+)?.json") ||
                        api.matches("^/me/groups.json") ||
                        api.matches("^/users/([0-9]+)/groups.json")
                ) {
            type = Type.GROUP;
        }
        if (type == null) {
            // TODO: throw exception if type is invalid
        }
        return type;
    }

    /**
     * Append get arguments (e.g. filters) to API.
     *
     * @param api
     * @param args
     * @return
     */
    private String appendGetArgs(String api, String[] args) {
        if (args != null) {
            if (args.length > 0 && args.length % 2 == 0) {
                api += "?";
                for (int i = 0, l = args.length; i < l; i += 2) {
                    if (i != 0) {
                        api += "&";
                    }
                    api += (args[i] + "=" + args[i + 1]);
                }
                if (this.token == null) {
                    api += ("&consumer_key=" + this.app_client_id);
                }
            }
        } else {
            api += "?consumer_key=" + this.app_client_id;
        }
        return api;
    }

    /**
     * The core of the library.
     *
     * @param api
     * @param rest
     * @param value
     * @param filters
     * @param <T>
     * @return
     */
    private <T> T api(String api, Rest rest, Object value, String[] filters) {
        api = this.filterApiString(api);
        Type type = this.defineApiType(api);
        api = this.appendGetArgs(api, filters);

        // TODO: execute each type of request in a separate method (get, post, put, delete)
        try {

            Request resource;
            HttpResponse response;
            String klass, content;

            switch (rest) {
                case GET:
                    response = wrapper.get(Request.to(api));

                    if (response.getStatusLine().getStatusCode() == 303) { // recursive better?
                        // System.out.println( "303: "+response.getFirstHeader("Location").getValue() );
                        api = (String) (response.getFirstHeader("Location").getValue() + ".json").replace("https://api.soundcloud.com", "");
                        response = wrapper.get(Request.to(api));
                    }

                    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                        String json = (String) (Http.formatJSON(Http.getString(response))).trim();

                        if (json.startsWith("[") && json.endsWith("]")) {
                            JSONArray data = (JSONArray) parser.parse(json);

                            if (data.size() > 0) {
                                switch (type) {
                                    case USER:
                                        ArrayList<User> users = new ArrayList<User>();
                                        for (int i = 0, l = data.size(); i < l; i++) {
                                            String tuple = data.get(i).toString();
                                            User user = gson.fromJson(replaceJsonsBlank(tuple), User.class);
                                            users.add(user);
                                        }
                                        return (T) users;
                                    case TRACK:
                                        ArrayList<Track> tracks = new ArrayList<Track>();
                                        for (int i = 0, l = data.size(); i < l; i++) {
                                            String tuple = data.get(i).toString();
                                            Track track = gson.fromJson(replaceJsonsBlank(tuple), Track.class);
                                            track.setSoundCloud(this);
                                            tracks.add(track);
                                        }
                                        return (T) tracks;
                                    case PLAYLIST:
                                        ArrayList<Playlist> playlists = new ArrayList<Playlist>();
                                        for (int i = 0, l = data.size(); i < l; i++) {
                                            String tuple = data.get(i).toString();
                                            Playlist playlist = gson.fromJson(replaceJsonsBlank(tuple), Playlist.class);
                                            playlists.add(playlist);
                                        }
                                        return (T) playlists;
                                    case COMMENT:
                                        ArrayList<Comment> comments = new ArrayList<Comment>();
                                        for (int i = 0, l = data.size(); i < l; i++) {
                                            String tuple = data.get(i).toString();
                                            Comment comment = gson.fromJson(replaceJsonsBlank(tuple), Comment.class);
                                            comments.add(comment);
                                        }
                                        return (T) comments;
                                    case GROUP:
                                        ArrayList<Group> groups = new ArrayList<Group>();
                                        for (int i = 0, l = data.size(); i < l; i++) {
                                            String tuple = data.get(i).toString();
                                            Group group = gson.fromJson(replaceJsonsBlank(tuple), Group.class);
                                            groups.add(group);
                                        }
                                        return (T) groups;
                                    default:
                                        return null;
                                }

                            }

                        } else {

                            switch (type) {
                                case USER:
                                    User user = gson.fromJson(replaceJsonsBlank(json), User.class);
                                    return (T) user;
                                case TRACK:
                                    Track track = gson.fromJson(replaceJsonsBlank(json), Track.class);
                                    track.setSoundCloud(this);
                                    return (T) track;
                                case PLAYLIST:
                                    Playlist playlist = gson.fromJson(replaceJsonsBlank(json), Playlist.class);
                                    return (T) playlist;
                                case COMMENT:
                                    Comment comment = gson.fromJson(replaceJsonsBlank(json), Comment.class);
                                    return (T) comment;
                                case GROUP:
                                    Group group = gson.fromJson(replaceJsonsBlank(json), Group.class);
                                    return (T) group;
                                default:
                                    return null;
                            }

                        }
                    } else {
                        System.err.println("Invalid status received: " + response.getStatusLine());
                    }
                    break;
                case POST:

                    klass = value.getClass().getName();
                    klass = klass.substring((klass.lastIndexOf('.') + 1));

                    if (klass.equals("Track")) {
                        Track track = ((Track) value);
                        resource = Request.to(Endpoints.TRACKS)
                                .add(Params.Track.TITLE, track.getTitle())
                                .add(Params.Track.TAG_LIST, track.getTagList())
                                .withFile(Params.Track.ASSET_DATA, new File(track.asset_data));
                    } else if (klass.equals("Comment")) {
                        content = gson.toJson(value);
                        content = "{\"comment\":" + content + "}";
                        resource = Request.to(api.replace(".json", ""))
                                .withContent(content, "application/json");
                    } else {
                        return null;
                    }

                    response = wrapper.post(resource);

                    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_CREATED) {
                        String json = (String) (Http.formatJSON(Http.getString(response))).trim();
                        switch (type) {
                            case TRACK:
                                Track track = gson.fromJson(replaceJsonsBlank(json), Track.class);
                                track.setSoundCloud(this);
                                return (T) track;
                            case COMMENT:
                                Comment comment = gson.fromJson(replaceJsonsBlank(json), Comment.class);
                                return (T) comment;
                            default:
                                return null;
                        }

                    } else {
                        System.err.println("Invalid status received: " + response.getStatusLine());
                    }

                    break;
                case PUT:

                    if (value != null) {

                        klass = value.getClass().getName();
                        klass = klass.substring((klass.lastIndexOf('.') + 1));

                        content = gson.toJson(value);

                        if (klass.equals("User")) {
                            content = "{\"user\":" + content + "}";
                        } else if (klass.equals("Track")) {
                            content = "{\"track\":" + content + "}";
                        } else {
                            return null;
                        }

                        resource = Request.to(api.replace(".json", "")).withContent(content, "application/json");
                    } else {
                        resource = Request.to(api.replace(".json", ""));
                    }

                    response = wrapper.put(resource);

                    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                        String json = (String) (Http.formatJSON(Http.getString(response))).trim();

                        switch (type) {
                            case USER:
                                User user = gson.fromJson(replaceJsonsBlank(json), User.class);
                                return (T) user;
                            case TRACK:
                                Track track = gson.fromJson(replaceJsonsBlank(json), Track.class);
                                track.setSoundCloud(this);
                                return (T) track;
                            default:
                                return null;
                        }
                    } else if (response.getStatusLine().getStatusCode() == HttpStatus.SC_CREATED) {
                        return (T) new Boolean(true);
                    } else {
                        System.err.println("Invalid status received: " + response.getStatusLine());
                    }

                    break;
                case DELETE:
                    response = wrapper.delete(Request.to(api));

                    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                        return (T) new Boolean(true);
                    }
                    return (T) new Boolean(false);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * API access to GET (REST) data.
     *
     * @param api
     * @return
     */
    public <T> T get(String api) {
        return this.api(api, Rest.GET, null, null);
    }

    /**
     * API access with filters to GET (REST) data.
     *
     * @param api
     * @param filters
     * @return
     */
    public <T> T get(String api, String[] filters) {
        return this.api(api, Rest.GET, null, filters);
    }


    /**
     * API access to POST (REST) new data.
     *
     * @param api
     * @return
     */
    public <T> T post(String api, Object value) {
        return this.api(api, Rest.POST, value, null);
    }


    /**
     * API access to PUT (REST) new data.
     *
     * @param api
     * @return
     */
    public <T> T put(String api) {
        return this.api(api, Rest.PUT, null, null);
    }

    /**
     * API access to PUT (REST) new data.
     *
     * @param api
     * @return
     */
    public <T> T put(String api, Object value) {
        return this.api(api, Rest.PUT, value, null);
    }


    /**
     * API access to DELETE (REST) data.
     *
     * @param api
     * @return
     */
    public Boolean delete(String api) {
        return (Boolean) this.api(api, Rest.DELETE, null, null);
    }


    /**
     * Get data about you.
     *
     * @return
     */
    public User getMe() {
        return this.get("me");
    }

    /**
     * Get your followings.
     *
     * @param offset
     * @param limit
     * @return
     */
    public ArrayList<User> getMeFollowings(Integer offset, Integer limit) {
        return this.get("me/followings", new String[]{
                "limit", Integer.toString(limit),
                "offset", Integer.toString(offset)
        });
    }

    /**
     * Get your last 50 followings.
     *
     * @return
     */
    public ArrayList<User> getMeFollowings() {
        return this.getMeFollowings(0, 50);
    }

    /**
     * Get a specific following.
     *
     * @param contact_id
     * @return
     */
    public User getMeFollowing(Integer contact_id) {
        return this.get("me/followings/" + Integer.toString(contact_id));
    }

    /**
     * Get your followers.
     *
     * @param offset
     * @param limit
     * @return
     */
    public ArrayList<User> getMeFollowers(Integer offset, Integer limit) {
        return this.get("me/followers", new String[]{
                "limit", Integer.toString(limit),
                "offset", Integer.toString(offset)
        });
    }

    /**
     * Get your last 50 followers.
     *
     * @return
     */
    public ArrayList<User> getMeFollowers() {
        return this.getMeFollowers(0, 50);
    }

    /**
     * Get a specific follower.
     *
     * @param contact_id
     * @return
     */
    public User getMeFollower(Integer contact_id) {
        return this.get("me/followers/" + Integer.toString(contact_id));
    }

    /**
     * Get your favorite tracks.
     *
     * @param limit
     * @param offset
     * @return
     */
    public ArrayList<Track> getMeFavorites(Integer offset, Integer limit) {
        return this.get("me/favorites", new String[]{
                "order", "created_at",
                "limit", Integer.toString(limit),
                "offset", Integer.toString(offset)
        });
    }

    /**
     * Get your last 50 favorite tracks.
     *
     * @return
     */
    public ArrayList<Track> getMeFavorites() {
        return this.getMeFavorites(0, 50);
    }

    /**
     * Get your last tracks.
     *
     * @param offset
     * @param limit
     * @return
     */
    public ArrayList<Track> getMeTracks(Integer offset, Integer limit) {
        return this.get("me/tracks", new String[]{
                "order", "created_at",
                "limit", Integer.toString(limit),
                "offset", Integer.toString(offset)
        });
    }

    /**
     * Get your last 50 tracks.
     *
     * @return
     */
    public ArrayList<Track> getMeTracks() {
        return this.getMeTracks(0, 50);
    }

    /**
     * Get your playlists.
     *
     * @return
     */
    public ArrayList<Playlist> getMePlaylists(Integer offset, Integer limit) {
        return this.get("me/playlists", new String[]{
                "order", "created_at",
                "limit", Integer.toString(limit),
                "offset", Integer.toString(offset)
        });
    }

    /**
     * Get your last 50 playlists.
     *
     * @return
     */
    public ArrayList<Playlist> getMePlaylists() {
        return this.getMePlaylists(0, 50);
    }

    /**
     * Get your groups.
     *
     * @return
     */
    public ArrayList<Group> getMeGroups(Integer offset, Integer limit) {
        return this.get("me/groups", new String[]{
                "order", "created_at",
                "limit", Integer.toString(limit),
                "offset", Integer.toString(offset)
        });
    }

    /**
     * Get your last 50 groups.
     *
     * @return
     */
    public ArrayList<Group> getMeGroups() {
        return this.getMeGroups(0, 50);
    }

    /**
     * Get your comments.
     *
     * @return
     */
    public ArrayList<Comment> getMeComments(Integer offset, Integer limit) {
        return this.get("me/comments", new String[]{
                "order", "created_at",
                "limit", Integer.toString(limit),
                "offset", Integer.toString(offset)
        });
    }

    /**
     * Get your last 50 comments.
     *
     * @return
     */
    public ArrayList<Comment> getMeComments() {
        return this.getMeComments(0, 50);
    }

    /**
     * Get comments from specific track.
     *
     * @param track_id
     * @return
     */
    public ArrayList<Comment> getCommentsFromTrack(Integer track_id) {
        return this.get("tracks/" + Integer.toString(track_id) + "/comments");
    }

    /**
     * Get a specific playlist.
     *
     * @param playlist_id
     * @return
     */
    public Playlist getPlaylist(Integer playlist_id) {
        return this.get("playlists/" + Integer.toString(playlist_id));
    }

    /**
     * Get last playlists.
     *
     * @param offset
     * @param limit
     * @return
     */
    public ArrayList<Playlist> getPlaylists(Integer offset, Integer limit) {
        return this.get("playlists", new String[]{
                "order", "created_at",
                "limit", Integer.toString(limit),
                "offset", Integer.toString(offset)
        });
    }

    /**
     * Get last 50 playlists.
     *
     * @return
     */
    public ArrayList<Playlist> getPlaylists() {
        return this.getPlaylists(0, 50);
    }

    /**
     * Get a specific user.
     *
     * @param contact_id
     * @return
     */
    public User getUser(Integer contact_id) {
        return this.get("users/" + Integer.toString(contact_id));
    }

    /**
     * Get last users.
     *
     * @param limit
     * @param offset
     * @return
     */
    public ArrayList<User> getUsers(Integer offset, Integer limit) {
        return this.get("users", new String[]{
                "order", "created_at",
                "limit", Integer.toString(limit),
                "offset", Integer.toString(offset)
        });
    }

    /**
     * Get last users.
     *
     * @return
     */
    public ArrayList<User> getUsers() {
        return this.getUsers(0, 50);
    }

    /**
     * Simple user search.
     *
     * @param username
     * @return
     */
    public ArrayList<User> findUser(String username) {
        return this.get("users", new String[]{
                "q", username
        });
    }

    /**
     * Get a specific track.
     *
     * @param track_id
     * @return
     */
    public Track getTrack(Integer track_id) {
        return this.get("tracks/" + Integer.toString(track_id));
    }

    /**
     * Get last tracks.
     *
     * @param offset
     * @param limit
     * @return
     */
    public ArrayList<Track> getTracks(Integer offset, Integer limit) {
        return this.get("tracks", new String[]{
                "order", "created_at",
                "limit", Integer.toString(limit),
                "offset", Integer.toString(offset)
        });
    }

    /**
     * Get last 50 tracks.
     *
     * @return
     */
    public ArrayList<Track> getTracks() {
        return this.getTracks(0, 50);
    }

    /**
     * Get tracks from specific group.
     *
     * @param group_id
     * @return
     */
    public ArrayList<Track> getTracksFromGroup(Integer group_id) {
        return this.get("groups/" + Integer.toString(group_id) + "/tracks");
    }

    /**
     * Simple track search.
     *
     * @param title
     * @return
     */
    public ArrayList<Track> findTrack(String title) {
        return this.get("tracks", new String[]{
                "q", title
        });
    }

    /**
     * Get a specific group.
     *
     * @param id
     * @return
     */
    public Group getGroup(Integer id) {
        return this.get("groups/" + Integer.toString(id));
    }

    /**
     * Get last groups.
     *
     * @param offset
     * @param limit
     * @return
     */
    public ArrayList<Group> getGroups(Integer offset, Integer limit) {
        return this.get("groups", new String[]{
                "order", "created_at",
                "limit", Integer.toString(limit),
                "offset", Integer.toString(offset)
        });
    }

    /**
     * Get last 50 groups.
     *
     * @return
     */
    public ArrayList<Group> getGroups() {
        return this.getGroups(0, 50);
    }

    /**
     * Simple user search.
     *
     * @param name
     * @return
     */
    public ArrayList<Group> findGroup(String name) {
        return this.get("groups", new String[]{
                "q", name
        });
    }

    /**
     * Update your account.
     *
     * @param user
     * @return
     */
    public User putMe(User user) {
        return this.put("me", user);
    }

    /**
     * Favor a specific track.
     *
     * @param track_id
     * @return
     */
    public Boolean putFavoriteTrack(Integer track_id) {
        return this.put("me/favorites/" + Integer.toString(track_id));
    }

    /**
     * Post a new track.
     *
     * @param track
     * @return
     */
    public Track postTrack(Track track) {
        return this.post("tracks", track);
    }

    /**
     * Post a new comment to a specific track.
     *
     * @param track_id
     * @param comment
     * @return
     */
    public Comment postCommentToTrack(Integer track_id, Comment comment) {
        return this.post("tracks/" + Integer.toString(track_id) + "/comments", comment);
    }

    /**
     * Delete a specific track.
     *
     * @param track_id
     * @return
     */
    public Boolean deleteTrack(Integer track_id) {
        return this.delete("tracks/" + Integer.toString(track_id));
    }

    /**
     * Remove a specific favorite track.
     *
     * @param track_id
     * @return
     */
    public Boolean deleteFavoriteTrack(Integer track_id) {
        return this.delete("me/favorites/" + Integer.toString(track_id));
    }

    /**
     * Clean JSON string.
     *
     * @param string
     * @return
     */
    private String replaceJsonsBlank(String string) {
        Pattern pattern = Pattern.compile(":(?: +)?\"\"");
        Matcher matcher = pattern.matcher(string);
        return matcher.replaceAll(":null");
    }

}